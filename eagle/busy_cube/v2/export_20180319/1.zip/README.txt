Created using Sparkgun CAM
